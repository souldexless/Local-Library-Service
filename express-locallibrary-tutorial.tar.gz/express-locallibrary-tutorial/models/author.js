/*
This scheme defines an author as having String SchemaTypes for the first
and family names, that are required and have a maxiumum of 100 characters,
and Date fields for the date of birth and death
*/

var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var AuthorSchema = Schema(
 {
     first_name: {type: String, required: true, max: 100},
     family_name: {type: String, required: true, max: 100},
     date_of_birth: {type: Date},
     date_of_death: {type: Date},
 }   
);

//Virtual for author's full name
AuthorSchema
.virtual('name')
.get(function() {
    return this.family_name + ', ' + this.first_name;
});

//Virtual for author's URL
AuthorSchema
.virtual('url')
.get(function() {
    return '/catalog/author/' + this._id;
});

//Export model 
module.exports = mongoose.model('Author', AuthorSchema);